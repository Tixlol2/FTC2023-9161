# Road Runner

A simple Kotlin library for planning 2D mobile robot paths and trajectories designed for FTC.

<p align="center">
    <img src="doc/image/8393.gif" />
</p>
<p align="center">(Courtesy of FTC Team 8393, Detroit 2019 Ochoa F2)</p>

## Documentation

Check out the [online documentation](https://rr.brott.dev/docs/)
